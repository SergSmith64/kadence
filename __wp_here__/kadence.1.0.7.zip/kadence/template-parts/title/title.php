<?php
/**
 * Template part for displaying a post's title
 *
 * @package kadence
 */

namespace Kadence;

the_title( '<h1 class="entry-title">', '</h1>' );
